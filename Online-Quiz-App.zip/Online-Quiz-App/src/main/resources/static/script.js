let questions = [];

fetch("/api/quiz/questions")
    .then(res => res.json())
    .then(data => {
        questions = data;
        displayQuestions();
    });

function displayQuestions() {
    const container = document.getElementById("quiz-container");
    container.innerHTML = "";
    questions.forEach((questionObj, index) => {
        let optionsHTML = "";
        questionObj.options.forEach((opt, i) => {
            optionsHTML += `
                <label>
                    <input type="radio" name="q${index}" value="${i}"> ${opt}
                </label><br>
            `;
        });
        container.innerHTML += `<div><p>${questionObj.question}</p>${optionsHTML}</div>`;
    });
}

document.getElementById("submitBtn").addEventListener("click", () => {
    const answers = questions.map((_, index) => {
        const selected = document.querySelector(`input[name="q${index}"]:checked`);
        return selected ? parseInt(selected.value) : -1;
    });

    fetch("/api/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(answers)
    })
    .then(res => res.json())
    .then(result => {
        document.getElementById("result").innerHTML =
            `Your Score: ${result.score} / ${result.total}`;
    });
});
