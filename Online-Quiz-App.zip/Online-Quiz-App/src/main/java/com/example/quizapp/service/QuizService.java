package com.example.quizapp.service;

import com.example.quizapp.model.Question;
import com.example.quizapp.model.QuizResult;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class QuizService {
    private List<Question> questions = new ArrayList<>(Arrays.asList(
            new Question("What is Java?", Arrays.asList("Language", "OS", "Browser", "Game"), 0),
            new Question("Spring Boot is used for?", Arrays.asList("Web Apps", "Gaming", "AI", "Cooking"), 0)
    ));

    public List<Question> getQuestions() {
        return questions;
    }

    public void addQuestion(Question q) {
        questions.add(q);
    }

    public QuizResult checkAnswers(List<Integer> answers) {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (i < answers.size() && answers.get(i) == questions.get(i).getCorrectAnswer()) {
                score++;
            }
        }
        return new QuizResult(score, questions.size());
    }
}
