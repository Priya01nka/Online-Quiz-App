package com.example.quizapp.controller;

import com.example.quizapp.model.Question;
import com.example.quizapp.model.QuizResult;
import com.example.quizapp.service.QuizService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/quiz")
public class QuizController {

    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }

    @GetMapping("/questions")
    public List<Question> getQuestions() {
        return quizService.getQuestions();
    }

    @PostMapping("/add")
    public void addQuestion(@RequestBody Question question) {
        quizService.addQuestion(question);
    }

    @PostMapping("/submit")
    public QuizResult submitAnswers(@RequestBody List<Integer> answers) {
        return quizService.checkAnswers(answers);
    }
}
