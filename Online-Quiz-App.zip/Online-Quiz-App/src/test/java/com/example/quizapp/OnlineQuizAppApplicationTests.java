package com.example.quizapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineQuizAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
